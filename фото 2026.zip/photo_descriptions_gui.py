"""
GUI для генерации описаний фото портфолио
Поддержка: Gemini API, BLIP-2, SmolVLM
"""

# ⚠️ ВАЖНО: Настраиваем путь для кэша моделей ПЕРЕД импортами
# Иначе модели скачаются на C:\Users\...\.cache\ (10GB!)
import os
MODELS_CACHE = os.path.join(os.path.dirname(__file__), 'models_cache')
os.makedirs(MODELS_CACHE, exist_ok=True)
os.environ['TRANSFORMERS_CACHE'] = os.path.join(MODELS_CACHE, 'transformers')
os.environ['HF_HOME'] = os.path.join(MODELS_CACHE, 'huggingface')
os.environ['TORCH_HOME'] = os.path.join(MODELS_CACHE, 'torch')

import csv
import time
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
from PIL import Image, ImageTk
import threading

ROOT = r'e:\цифра 2026 хп\фото 2026'
CSV_FILE = os.path.join(ROOT, 'master_portfolio_import.csv')
OUTPUT_CSV = os.path.join(ROOT, 'master_portfolio_import_enriched.csv')

PROMPT_RU = """Ты - эксперт по созданию описаний для портфолио рекламной продукции.

Изображение: фото продукции категории "{category}"

Создай ПРОФЕССИОНАЛЬНОЕ описание для портфолио (400-500 символов) включающее:
1. Что именно изображено (тип продукта, материал, размер если виден)
2. Какой логотип/дизайн нанесен и каким методом (печать, гравировка, вышивка)
3. Особенности исполнения (цвета, качество, детали)
4. Для кого подходит или область применения

Формат ответа - связный текст БЕЗ заголовков и списков, как для каталога.
Язык: русский, профессиональный стиль.

Описание:"""


class ModelManager:
    """Менеджер моделей CV"""
    
    def __init__(self, log_callback=None):
        self.model = None
        self.processor = None
        self.current_method = None
        self.log_callback = log_callback
    
    def log(self, message):
        if self.log_callback:
            self.log_callback(message)
        else:
            print(message)
    
    def load_model(self, method, api_key=None):
        """Загрузка модели"""
        self.current_method = method
        
        if method == 'gemini':
            return self._load_gemini(api_key)
        elif method == 'blip2':
            return self._load_blip2()
        elif method == 'smolvlm':
            return self._load_smolvlm()
        return False
    
    def _load_gemini(self, api_key):
        try:
            import google.generativeai as genai
            if not api_key:
                self.log("❌ Необходим API ключ для Gemini!")
                return False
            
            genai.configure(api_key=api_key)
            self.model = genai.GenerativeModel('gemini-1.5-flash')
            self.log("✅ Gemini Flash загружен")
            return True
        except ImportError:
            self.log("❌ Установите: pip install google-generativeai")
            return False
        except Exception as e:
            self.log(f"❌ Ошибка: {e}")
            return False
    
    def _load_blip2(self):
        try:
            from transformers import Blip2Processor, Blip2ForConditionalGeneration
            import torch
            
            self.log("⏳ Загрузка BLIP-2 (первый раз ~10GB)...")
            self.processor = Blip2Processor.from_pretrained("Salesforce/blip2-opt-2.7b")
            self.model = Blip2ForConditionalGeneration.from_pretrained(
                "Salesforce/blip2-opt-2.7b",
                torch_dtype=torch.float32,
            )
            self.log("✅ BLIP-2 загружен (CPU)")
            return True
        except Exception as e:
            self.log(f"❌ Ошибка: {e}")
            return False
    
    def _load_smolvlm(self):
        try:
            from transformers import AutoProcessor, AutoModelForVision2Seq
            import torch
            
            self.log("⏳ Загрузка SmolVLM (~2GB)...")
            self.processor = AutoProcessor.from_pretrained("HuggingFaceTB/SmolVLM-Instruct")
            self.model = AutoModelForVision2Seq.from_pretrained(
                "HuggingFaceTB/SmolVLM-Instruct",
                torch_dtype=torch.float32,
            )
            self.log("✅ SmolVLM загружен (CPU)")
            return True
        except Exception as e:
            self.log(f"❌ Ошибка: {e}")
            return False
    
    def generate_description(self, image_path, category, title):
        """Генерация описания"""
        try:
            image = Image.open(image_path).convert('RGB')
            
            if self.current_method == 'gemini':
                prompt = PROMPT_RU.format(category=category)
                response = self.model.generate_content([prompt, image])
                return response.text.strip()
                
            elif self.current_method == 'blip2':
                prompt = f"Question: Describe this {category} product in detail. Answer:"
                inputs = self.processor(image, text=prompt, return_tensors="pt")
                generated_ids = self.model.generate(**inputs, max_length=150)
                desc = self.processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
                return f"[EN] {desc}"
                
            elif self.current_method == 'smolvlm':
                prompt = f"Опиши подробно этот продукт '{category}': материал, логотип, метод нанесения, особенности."
                messages = [{"role": "user", "content": [{"type": "image"}, {"type": "text", "text": prompt}]}]
                inputs = self.processor.apply_chat_template(messages, add_generation_prompt=True, return_tensors="pt")
                generated_ids = self.model.generate(**inputs, max_new_tokens=200)
                desc = self.processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
                return desc.strip()
                
        except Exception as e:
            self.log(f"❌ Ошибка генерации: {e}")
            return None


class PhotoDescriptionGUI:
    """Главное окно приложения"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("Генератор описаний фото портфолио")
        self.root.geometry("1000x800")
        
        self.manager = ModelManager(log_callback=self.log)
        self.csv_rows = []
        self.current_image_path = None
        self.processing = False
        
        self.setup_ui()
        self.load_csv()
    
    def setup_ui(self):
        """Создание интерфейса"""
        
        # Верхняя панель - настройки
        top_frame = ttk.LabelFrame(self.root, text="⚙️ Настройки", padding=10)
        top_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Выбор модели
        ttk.Label(top_frame, text="Модель:").grid(row=0, column=0, sticky=tk.W, padx=5)
        self.model_var = tk.StringVar(value="gemini")
        models = [
            ("Gemini Flash (API, быстро)", "gemini"),
            ("BLIP-2 (локально, медленно)", "blip2"),
            ("SmolVLM (локально, средне)", "smolvlm")
        ]
        for i, (text, value) in enumerate(models):
            ttk.Radiobutton(top_frame, text=text, variable=self.model_var, value=value,
                          command=self.on_model_change).grid(row=0, column=i+1, padx=5)
        
        # API ключ
        ttk.Label(top_frame, text="Gemini API Key:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=5)
        self.api_key_var = tk.StringVar()
        self.api_entry = ttk.Entry(top_frame, textvariable=self.api_key_var, width=50, show="*")
        self.api_entry.grid(row=1, column=1, columnspan=2, sticky=tk.W, padx=5)
        
        ttk.Button(top_frame, text="Показать", command=self.toggle_api_visibility).grid(row=1, column=3, padx=5)
        
        # Количество фото
        ttk.Label(top_frame, text="Обработать (фото):").grid(row=2, column=0, sticky=tk.W, padx=5, pady=5)
        self.count_var = tk.IntVar(value=10)
        ttk.Spinbox(top_frame, from_=1, to=1000, textvariable=self.count_var, width=10).grid(row=2, column=1, sticky=tk.W, padx=5)
        
        # Средняя панель - превью и информация
        middle_frame = ttk.Frame(self.root)
        middle_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Левая часть - превью изображения
        left_panel = ttk.LabelFrame(middle_frame, text="🖼️ Превью", padding=10)
        left_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        self.image_label = ttk.Label(left_panel, text="Загрузите изображение...", anchor=tk.CENTER)
        self.image_label.pack(fill=tk.BOTH, expand=True)
        
        self.info_label = ttk.Label(left_panel, text="", anchor=tk.CENTER, font=("Arial", 9))
        self.info_label.pack(pady=5)
        
        # Правая часть - описание
        right_panel = ttk.LabelFrame(middle_frame, text="📝 Сгенерированное описание", padding=10)
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))
        
        self.description_text = scrolledtext.ScrolledText(right_panel, wrap=tk.WORD, height=15, font=("Arial", 10))
        self.description_text.pack(fill=tk.BOTH, expand=True)
        
        # Панель управления
        control_frame = ttk.Frame(self.root)
        control_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Button(control_frame, text="🧪 Тест на 1 фото", command=self.test_single, 
                  style="Accent.TButton").pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="🚀 Обработать партию", command=self.process_batch,
                  style="Accent.TButton").pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="⏹️ Стоп", command=self.stop_processing).pack(side=tk.LEFT, padx=5)
        
        # Прогресс бар
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(control_frame, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=10)
        
        self.progress_label = ttk.Label(control_frame, text="0/0")
        self.progress_label.pack(side=tk.LEFT, padx=5)
        
        # Лог
        log_frame = ttk.LabelFrame(self.root, text="📋 Лог", padding=10)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        self.log_text = scrolledtext.ScrolledText(log_frame, wrap=tk.WORD, height=8, font=("Consolas", 9))
        self.log_text.pack(fill=tk.BOTH, expand=True)
    
    def on_model_change(self):
        """Обработка смены модели"""
        model = self.model_var.get()
        if model == 'gemini':
            self.api_entry.config(state='normal')
        else:
            self.api_entry.config(state='disabled')
    
    def toggle_api_visibility(self):
        """Показать/скрыть API ключ"""
        if self.api_entry['show'] == '*':
            self.api_entry['show'] = ''
        else:
            self.api_entry['show'] = '*'
    
    def log(self, message):
        """Добавить сообщение в лог"""
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.root.update()
    
    def load_csv(self):
        """Загрузка CSV"""
        try:
            with open(CSV_FILE, 'r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f)
                self.csv_rows = list(reader)
                self.fieldnames = reader.fieldnames
            
            # Добавляем поля если нужно
            if 'ai_description' not in self.fieldnames:
                self.fieldnames = list(self.fieldnames) + ['ai_description', 'ai_method']
            
            total = len(self.csv_rows)
            need_processing = sum(1 for r in self.csv_rows if not r.get('ai_description', '').strip())
            
            self.log(f"✅ Загружено записей: {total}")
            self.log(f"📊 Требуют обработки: {need_processing}")
            
        except Exception as e:
            self.log(f"❌ Ошибка загрузки CSV: {e}")
    
    def show_image(self, image_path):
        """Отобразить изображение"""
        try:
            img = Image.open(image_path)
            img.thumbnail((400, 400))
            photo = ImageTk.PhotoImage(img)
            
            self.image_label.config(image=photo, text="")
            self.image_label.image = photo
            
            self.current_image_path = image_path
            
        except Exception as e:
            self.log(f"❌ Ошибка загрузки изображения: {e}")
    
    def test_single(self):
        """Тест на одном фото"""
        if self.processing:
            messagebox.showwarning("Внимание", "Уже идет обработка!")
            return
        
        # Находим первое фото без описания
        test_row = None
        for row in self.csv_rows:
            if not row.get('ai_description', '').strip():
                local_path = row.get('file_path_local', '')
                full_path = os.path.join(ROOT, local_path)
                if os.path.exists(full_path):
                    test_row = row
                    break
        
        if not test_row:
            messagebox.showinfo("Инфо", "Не найдено фото для тестирования")
            return
        
        # Запускаем в отдельном потоке
        threading.Thread(target=self._test_single_worker, args=(test_row,), daemon=True).start()
    
    def _test_single_worker(self, row):
        """Воркер для теста"""
        self.processing = True
        
        try:
            # Загружаем модель
            method = self.model_var.get()
            api_key = self.api_key_var.get() if method == 'gemini' else None
            
            self.log(f"\n🔄 Загрузка модели: {method.upper()}")
            
            if not self.manager.load_model(method, api_key):
                self.processing = False
                return
            
            # Показываем изображение
            local_path = row.get('file_path_local', '')
            full_path = os.path.join(ROOT, local_path)
            
            self.root.after(0, self.show_image, full_path)
            self.root.after(0, self.info_label.config, 
                          {'text': f"{os.path.basename(local_path)}\nКатегория: {row.get('tax_category', 'N/A')}"})
            
            # Генерируем описание
            self.log("🔍 Генерация описания...")
            
            category = row.get('tax_category', 'Продукция')
            title = row.get('post_title', '')
            
            start_time = time.time()
            description = self.manager.generate_description(full_path, category, title)
            elapsed = time.time() - start_time
            
            if description:
                self.log(f"✅ Готово за {elapsed:.1f} сек")
                self.log(f"📏 Длина: {len(description)} символов\n")
                
                # Показываем описание
                self.root.after(0, self.description_text.delete, 1.0, tk.END)
                self.root.after(0, self.description_text.insert, 1.0, description)
            else:
                self.log("❌ Не удалось сгенерировать описание")
                
        finally:
            self.processing = False
    
    def process_batch(self):
        """Пакетная обработка"""
        if self.processing:
            messagebox.showwarning("Внимание", "Уже идет обработка!")
            return
        
        count = self.count_var.get()
        
        if messagebox.askyesno("Подтверждение", f"Обработать {count} фото?"):
            threading.Thread(target=self._process_batch_worker, args=(count,), daemon=True).start()
    
    def _process_batch_worker(self, max_count):
        """Воркер для пакетной обработки"""
        self.processing = True
        
        try:
            # Загружаем модель
            method = self.model_var.get()
            api_key = self.api_key_var.get() if method == 'gemini' else None
            
            self.log(f"\n🚀 Начинаем пакетную обработку ({max_count} фото)")
            self.log(f"Модель: {method.upper()}\n")
            
            if not self.manager.load_model(method, api_key):
                self.processing = False
                return
            
            # Фильтруем фото без описаний
            to_process = []
            for i, row in enumerate(self.csv_rows):
                if not row.get('ai_description', '').strip():
                    local_path = row.get('file_path_local', '')
                    full_path = os.path.join(ROOT, local_path)
                    if os.path.exists(full_path):
                        to_process.append((i, row, full_path))
                        if len(to_process) >= max_count:
                            break
            
            total = len(to_process)
            self.log(f"📊 Будет обработано: {total}")
            
            processed = 0
            errors = 0
            
            for idx, (row_idx, row, full_path) in enumerate(to_process):
                if not self.processing:  # Проверка на остановку
                    self.log("⏹️ Обработка остановлена пользователем")
                    break
                
                # Обновляем прогресс
                progress = (idx + 1) / total * 100
                self.root.after(0, self.progress_var.set, progress)
                self.root.after(0, self.progress_label.config, {'text': f"{idx+1}/{total}"})
                
                # Показываем текущее фото
                self.root.after(0, self.show_image, full_path)
                
                category = row.get('tax_category', 'Продукция')
                title = row.get('post_title', '')
                
                self.log(f"{idx+1}/{total} 🔍 {os.path.basename(full_path)}")
                
                # Генерируем описание
                description = self.manager.generate_description(full_path, category, title)
                
                if description and len(description) > 50:
                    # Форматируем в HTML
                    html_desc = self._format_html(description, category)
                    
                    # Обновляем данные
                    self.csv_rows[row_idx]['ai_description'] = description
                    self.csv_rows[row_idx]['post_content'] = html_desc
                    self.csv_rows[row_idx]['ai_method'] = method
                    
                    processed += 1
                    self.log(f"   ✅ {len(description)} символов")
                    
                    # Показываем описание
                    self.root.after(0, self.description_text.delete, 1.0, tk.END)
                    self.root.after(0, self.description_text.insert, 1.0, description)
                    
                    # Автосохранение каждые 5
                    if processed % 5 == 0:
                        self._save_csv()
                        self.log(f"   💾 Автосохранение: {processed}")
                else:
                    errors += 1
                    self.log(f"   ❌ Ошибка генерации")
                
                # Rate limiting для API
                if method == 'gemini':
                    time.sleep(1)
            
            # Финальное сохранение
            self._save_csv()
            
            self.log(f"\n{'='*50}")
            self.log(f"✅ ОБРАБОТКА ЗАВЕРШЕНА!")
            self.log(f"   Успешно: {processed}")
            self.log(f"   Ошибок: {errors}")
            self.log(f"   CSV: {OUTPUT_CSV}")
            self.log(f"{'='*50}\n")
            
            self.root.after(0, messagebox.showinfo, "Готово", 
                          f"Обработано: {processed}\nОшибок: {errors}")
            
        finally:
            self.processing = False
            self.root.after(0, self.progress_var.set, 0)
            self.root.after(0, self.progress_label.config, {'text': "0/0"})
    
    def _format_html(self, description, category):
        """Форматирование в HTML"""
        html = f"""<p><strong>Описание:</strong> {description}</p>
<p>Профессиональное нанесение логотипа методом печати, гравировки или вышивки. Индивидуальный дизайн под заказ.</p>
<p><em>Категория: {category}</em></p>"""
        return html
    
    def _save_csv(self):
        """Сохранение CSV"""
        try:
            with open(OUTPUT_CSV, 'w', encoding='utf-8-sig', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=self.fieldnames)
                writer.writeheader()
                writer.writerows(self.csv_rows)
        except Exception as e:
            self.log(f"❌ Ошибка сохранения: {e}")
    
    def stop_processing(self):
        """Остановка обработки"""
        if self.processing:
            self.processing = False
            self.log("⏹️ Остановка обработки...")


if __name__ == "__main__":
    root = tk.Tk()
    app = PhotoDescriptionGUI(root)
    root.mainloop()
