import os
import glob

ROOT = r'e:\цифра 2026 хп\фото 2026'

def audit():
    results = []
    folders = [d for d in os.listdir(ROOT) if os.path.isdir(os.path.join(ROOT, d))]
    
    print(f"{'Folder':<30} | {'Images':<7} | {'CSV?':<5} | {'Organized?'}")
    print("-" * 60)
    
    for folder in folders:
        path = os.path.join(ROOT, folder)
        images = glob.glob(os.path.join(path, '**', '*.jpg'), recursive=True) + \
                 glob.glob(os.path.join(path, '**', '*.jpeg'), recursive=True) + \
                 glob.glob(os.path.join(path, '**', '*.png'), recursive=True)
        
        csv_files = glob.glob(os.path.join(path, '*.csv'))
        org_dirs = [d for d in os.listdir(path) if os.path.isdir(os.path.join(path, d)) and d[0].isdigit() and '_' in d]
        
        has_csv = "YES" if csv_files else "NO"
        is_org = "YES" if org_dirs else "NO"
        
        print(f"{folder:<30} | {len(images):<7} | {has_csv:<5} | {is_org}")
        results.append({
            'folder': folder,
            'image_count': len(images),
            'has_csv': has_csv == "YES",
            'is_organized': is_org == "YES"
        })
    
    return results

if __name__ == "__main__":
    audit()
