@echo off
chcp 65001 >nul
title Настройка пути для моделей

echo ================================================
echo   НАСТРОЙКА ПУТИ ДЛЯ МОДЕЛЕЙ CV
echo ================================================
echo.
echo По умолчанию модели скачиваются на диск C:
echo   C:\Users\%USERNAME%\.cache\huggingface\
echo.
echo Это займет ~2-10GB места!
echo.
echo ❗ Мы настроим путь на диск E:
echo   e:\цифра 2026 хп\фото 2026\models_cache\
echo.

set MODELS_PATH=e:\цифра 2026 хп\фото 2026\models_cache

REM Создаем папку если её нет
if not exist "%MODELS_PATH%" (
    echo Создаем папку для моделей...
    mkdir "%MODELS_PATH%"
    echo ✅ Папка создана: %MODELS_PATH%
) else (
    echo ✅ Папка уже существует: %MODELS_PATH%
)

echo.
echo ====================================================
echo   ПЕРЕМЕННЫЕ ОКРУЖЕНИЯ
echo ====================================================
echo.
echo Устанавливаем для текущей сессии:
echo   TRANSFORMERS_CACHE=%MODELS_PATH%\transformers
echo   HF_HOME=%MODELS_PATH%\huggingface
echo   TORCH_HOME=%MODELS_PATH%\torch
echo.

set TRANSFORMERS_CACHE=%MODELS_PATH%\transformers
set HF_HOME=%MODELS_PATH%\huggingface
set TORCH_HOME=%MODELS_PATH%\torch

echo ✅ Переменные установлены для текущей сессии
echo.
echo ====================================================
echo.
echo Хотите установить PERMANENTLY (постоянно)?
echo Это добавит переменные в реестр Windows.
echo.
set /p permanent="Установить постоянно? [y/N]: "

if /i "%permanent%"=="y" (
    echo.
    echo Добавляем в системные переменные...
    
    setx TRANSFORMERS_CACHE "%MODELS_PATH%\transformers"
    setx HF_HOME "%MODELS_PATH%\huggingface"
    setx TORCH_HOME "%MODELS_PATH%\torch"
    
    echo ✅ Переменные установлены постоянно!
    echo.
    echo ⚠️  ВАЖНО: Перезапустите терминал/IDE чтобы изменения вступили в силу!
) else (
    echo.
    echo ⚠️  Переменные действуют только в этом окне
    echo    Для постоянной установки запустите снова и выберите 'y'
)

echo.
echo ====================================================
echo.
echo 💡 Теперь все модели будут скачиваться сюда:
echo    %MODELS_PATH%
echo.
echo Текущий размер кэша:
dir "%MODELS_PATH%" 2>nul

echo.
echo ====================================================
pause
