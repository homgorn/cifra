"""
Генерация SEO-описаний для портфолио с поддержкой разных моделей CV
Описания в HTML формате для WordPress, до 500 символов
"""

# ⚠️ ВАЖНО: Настраиваем путь для кэша моделей ПЕРЕД импортами
import os
MODELS_CACHE = os.path.join(os.path.dirname(__file__), 'models_cache')
os.makedirs(MODELS_CACHE, exist_ok=True)
os.environ['TRANSFORMERS_CACHE'] = os.path.join(MODELS_CACHE, 'transformers')
os.environ['HF_HOME'] = os.path.join(MODELS_CACHE, 'huggingface')
os.environ['TORCH_HOME'] = os.path.join(MODELS_CACHE, 'torch')

import csv
import time
from PIL import Image
from pathlib import Path

ROOT = r'e:\цифра 2026 хп\фото 2026'
CSV_FILE = os.path.join(ROOT, 'master_portfolio_import.csv')
OUTPUT_CSV = os.path.join(ROOT, 'master_portfolio_import_enriched.csv')

# Промпт для генерации описаний портфолио
PROMPT_RU = """Ты - эксперт по созданию описаний для портфолио рекламной продукции.

Изображение: фото продукции категории "{category}"

Создай ПРОФЕССИОНАЛЬНОЕ описание для портфолио (400-500 символов) включающее:
1. Что именно изображено (тип продукта, материал, размер если виден)
2. Какой логотип/дизайн нанесен и каким методом (печать, гравировка, вышивка)
3. Особенности исполнения (цвета, качество, детали)
4. Для кого подходит или область применения

Формат ответа - связный текст БЕЗ заголовков и списков, как для каталога.
Язык: русский, профессиональный стиль.

Описание:"""


class ModelManager:
    """Менеджер для работы с разными моделями"""
    
    def __init__(self):
        self.available_models = {
            'gemini': {'name': 'Google Gemini Flash', 'type': 'API', 'speed': 'Быстро'},
            'blip2': {'name': 'BLIP-2 (Salesforce)', 'type': 'Локально', 'speed': 'Медленно'},
            'smolvlm': {'name': 'SmolVLM', 'type': 'Локально', 'speed': 'Средне'}
        }
        self.model = None
        self.processor = None
        self.current_method = None
    
    def show_available_models(self):
        """Показать доступные модели"""
        print("\n" + "="*60)
        print("  ДОСТУПНЫЕ МОДЕЛИ ДЛЯ ГЕНЕРАЦИИ ОПИСАНИЙ")
        print("="*60)
        for i, (key, info) in enumerate(self.available_models.items(), 1):
            print(f"{i}. {info['name']}")
            print(f"   Тип: {info['type']} | Скорость: {info['speed']}")
            if key == 'gemini':
                print(f"   💡 Требуется API ключ (бесплатно)")
            else:
                print(f"   💡 Первый запуск скачает ~2-10GB")
            print()
    
    def load_model(self, method, api_key=None):
        """Загрузить выбранную модель"""
        self.current_method = method
        
        if method == 'gemini':
            return self._load_gemini(api_key)
        elif method == 'blip2':
            return self._load_blip2()
        elif method == 'smolvlm':
            return self._load_smolvlm()
        
        return False
    
    def _load_gemini(self, api_key):
        """Загрузка Gemini"""
        try:
            import google.generativeai as genai
            if not api_key:
                print("❌ Необходим API ключ для Gemini!")
                print("   Получите здесь: https://makersuite.google.com/app/apikey")
                return False
            
            genai.configure(api_key=api_key)
            self.model = genai.GenerativeModel('gemini-1.5-flash')
            print("✅ Gemini Flash загружен")
            return True
        except ImportError:
            print("❌ Установите: pip install google-generativeai")
            return False
        except Exception as e:
            print(f"❌ Ошибка загрузки Gemini: {e}")
            return False
    
    def _load_blip2(self):
        """Загрузка BLIP-2"""
        try:
            from transformers import Blip2Processor, Blip2ForConditionalGeneration
            import torch
            
            print("⏳ Загрузка BLIP-2 (первый раз скачает ~10GB, подождите)...")
            self.processor = Blip2Processor.from_pretrained("Salesforce/blip2-opt-2.7b")
            self.model = Blip2ForConditionalGeneration.from_pretrained(
                "Salesforce/blip2-opt-2.7b",
                torch_dtype=torch.float32,
            )
            print("✅ BLIP-2 загружен (работает на CPU)")
            return True
        except ImportError:
            print("❌ Установите: pip install transformers torch")
            return False
        except Exception as e:
            print(f"❌ Ошибка загрузки BLIP-2: {e}")
            return False
    
    def _load_smolvlm(self):
        """Загрузка SmolVLM"""
        try:
            from transformers import AutoProcessor, AutoModelForVision2Seq
            import torch
            
            print("⏳ Загрузка SmolVLM (первый раз скачает ~2GB)...")
            self.processor = AutoProcessor.from_pretrained("HuggingFaceTB/SmolVLM-Instruct")
            self.model = AutoModelForVision2Seq.from_pretrained(
                "HuggingFaceTB/SmolVLM-Instruct",
                torch_dtype=torch.float32,
            )
            print("✅ SmolVLM загружен (работает на CPU)")
            return True
        except ImportError:
            print("❌ Установите: pip install transformers torch")
            return False
        except Exception as e:
            print(f"❌ Ошибка загрузки SmolVLM: {e}")
            return False
    
    def generate_description(self, image_path, category, title):
        """Генерация описания изображения"""
        try:
            image = Image.open(image_path).convert('RGB')
            
            if self.current_method == 'gemini':
                return self._generate_gemini(image, category, title)
            elif self.current_method == 'blip2':
                return self._generate_blip2(image, category, title)
            elif self.current_method == 'smolvlm':
                return self._generate_smolvlm(image, category, title)
                
        except Exception as e:
            print(f"   ❌ Ошибка: {e}")
            return None
    
    def _generate_gemini(self, image, category, title):
        """Генерация через Gemini"""
        prompt = PROMPT_RU.format(category=category)
        response = self.model.generate_content([prompt, image])
        return response.text.strip()
    
    def _generate_blip2(self, image, category, title):
        """Генерация через BLIP-2"""
        # BLIP-2 работает на английском
        prompt = f"Question: Describe this {category} product in detail, including logo, printing method, colors, and purpose. Answer:"
        inputs = self.processor(image, text=prompt, return_tensors="pt")
        
        generated_ids = self.model.generate(
            **inputs,
            max_length=150,
            num_beams=5,
            temperature=0.7
        )
        description_en = self.processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
        
        # Базовый перевод (для полноценного нужен translate API)
        # Пока возвращаем на английском с префиксом
        return f"[EN] {description_en}"
    
    def _generate_smolvlm(self, image, category, title):
        """Генерация через SmolVLM"""
        prompt = f"Опиши подробно этот продукт категории '{category}': что изображено, какой логотип, метод нанесения, особенности."
        
        messages = [{"role": "user", "content": [{"type": "image"}, {"type": "text", "text": prompt}]}]
        inputs = self.processor.apply_chat_template(messages, add_generation_prompt=True, return_tensors="pt")
        
        generated_ids = self.model.generate(
            **inputs,
            max_new_tokens=200,
            temperature=0.7
        )
        description = self.processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
        return description.strip()


def html_format_description(raw_description, category, method_used):
    """Форматирование описания в HTML для WordPress"""
    
    # Очищаем от лишних символов
    description = raw_description.strip()
    
    # Формируем HTML
    html = f"""<p><strong>Описание:</strong> {description}</p>
<p>Профессиональное нанесение логотипа методом печати, гравировки или вышивки. Индивидуальный дизайн под заказ.</p>
<p><em>Категория: {category}</em></p>"""
    
    return html


def test_models_on_sample(sample_image_path, category, title):
    """Тестирование всех моделей на одном изображении"""
    
    print("\n" + "="*60)
    print("  ТЕСТОВЫЙ РЕЖИМ: Сравнение моделей")
    print("="*60)
    print(f"Тестовое изображение: {os.path.basename(sample_image_path)}")
    print(f"Категория: {category}")
    print()
    
    manager = ModelManager()
    results = {}
    
    # Тестируем Gemini
    print("1️⃣  Тестирование Gemini Flash...")
    api_key = input("   Введите Gemini API ключ (Enter для пропуска): ").strip()
    if api_key:
        if manager.load_model('gemini', api_key):
            start_time = time.time()
            desc = manager.generate_description(sample_image_path, category, title)
            elapsed = time.time() - start_time
            if desc:
                results['gemini'] = {'description': desc, 'time': elapsed}
                print(f"   ✅ Готово за {elapsed:.1f} сек")
                print(f"   Длина: {len(desc)} символов")
    else:
        print("   ⏭️  Пропущено")
    
    # Тестируем BLIP-2
    print("\n2️⃣  Тестирование BLIP-2...")
    confirm = input("   Загрузить BLIP-2? (~10GB, медленно) [y/N]: ").strip().lower()
    if confirm == 'y':
        if manager.load_model('blip2'):
            start_time = time.time()
            desc = manager.generate_description(sample_image_path, category, title)
            elapsed = time.time() - start_time
            if desc:
                results['blip2'] = {'description': desc, 'time': elapsed}
                print(f"   ✅ Готово за {elapsed:.1f} сек")
                print(f"   Длина: {len(desc)} символов")
    else:
        print("   ⏭️  Пропущено")
    
    # Тестируем SmolVLM
    print("\n3️⃣  Тестирование SmolVLM...")
    confirm = input("   Загрузить SmolVLM? (~2GB) [y/N]: ").strip().lower()
    if confirm == 'y':
        if manager.load_model('smolvlm'):
            start_time = time.time()
            desc = manager.generate_description(sample_image_path, category, title)
            elapsed = time.time() - start_time
            if desc:
                results['smolvlm'] = {'description': desc, 'time': elapsed}
                print(f"   ✅ Готово за {elapsed:.1f} сек")
                print(f"   Длина: {len(desc)} символов")
    else:
        print("   ⏭️  Пропущено")
    
    # Показываем результаты
    if results:
        print("\n" + "="*60)
        print("  РЕЗУЛЬТАТЫ СРАВНЕНИЯ")
        print("="*60)
        
        for method, data in results.items():
            print(f"\n🔹 {method.upper()}")
            print(f"   Время: {data['time']:.1f} сек")
            print(f"   Описание ({len(data['description'])} символов):")
            print(f"   {data['description'][:200]}...")
            print()
        
        print("\n💡 Выберите лучшую модель для полной обработки")
    else:
        print("\n⚠️  Не было протестировано ни одной модели")


def process_images_batch(method, api_key=None, start_index=0, max_count=50):
    """Пакетная обработка изображений"""
    
    # Загружаем CSV
    print(f"\n📊 Загружаем CSV: {CSV_FILE}")
    with open(CSV_FILE, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
        fieldnames = reader.fieldnames
    
    # Добавляем новые поля если их нет
    if 'ai_description' not in fieldnames:
        fieldnames = list(fieldnames) + ['ai_description', 'ai_method']
    
    print(f"Всего записей: {len(rows)}")
    
    # Фильтруем для обработки
    to_process = []
    for i, row in enumerate(rows):
        content = row.get('post_content', '')
        has_ai = row.get('ai_description', '').strip()
        
        if not has_ai:  # Обрабатываем только без AI описаний
            to_process.append((i, row))
    
    print(f"Требуют обработки: {len(to_process)}")
    
    # Применяем ограничения
    to_process = to_process[start_index:start_index+max_count if max_count else None]
    print(f"Будет обработано: {len(to_process)}")
    
    if not to_process:
        print("✅ Нечего обрабатывать!")
        return
    
    # Загружаем модель
    manager = ModelManager()
    if not manager.load_model(method, api_key):
        print("❌ Не удалось загрузить модель")
        return
    
    print(f"\n🚀 Начинаем обработку...\n")
    
    processed = 0
    errors = 0
    
    for idx, (row_idx, row) in enumerate(to_process):
        local_path = row.get('file_path_local', '')
        full_path = os.path.join(ROOT, local_path)
        category = row.get('tax_category', 'Продукция')
        title = row.get('post_title', '')
        
        if not os.path.exists(full_path):
            print(f"{idx+1}/{len(to_process)} ⏭️  Файл не найден")
            errors += 1
            continue
        
        print(f"{idx+1}/{len(to_process)} 🔍 {os.path.basename(local_path)}...", end=" ", flush=True)
        
        # Генерируем описание
        raw_desc = manager.generate_description(full_path, category, title)
        
        if raw_desc and len(raw_desc) > 50:
            # Форматируем в HTML
            html_desc = html_format_description(raw_desc, category, method)
            
            # Обновляем запись
            rows[row_idx]['ai_description'] = raw_desc  # Plain text для хранения
            rows[row_idx]['post_content'] = html_desc   # HTML для WordPress
            rows[row_idx]['ai_method'] = method
            
            processed += 1
            print(f"✅ ({len(raw_desc)} симв.)")
            
            # Автосохранение каждые 10
            if processed % 10 == 0:
                save_csv(rows, fieldnames)
                print(f"   💾 Сохранено: {processed}")
        else:
            errors += 1
            print("❌")
        
        # Rate limiting для API
        if method == 'gemini':
            time.sleep(1)
    
    # Финальное сохранение
    save_csv(rows, fieldnames)
    
    print(f"\n{'='*60}")
    print(f"✅ ОБРАБОТКА ЗАВЕРШЕНА!")
    print(f"   Успешно: {processed}")
    print(f"   Ошибок: {errors}")
    print(f"   CSV: {OUTPUT_CSV}")
    print(f"{'='*60}")


def save_csv(rows, fieldnames):
    """Сохранение CSV"""
    with open(OUTPUT_CSV, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main():
    """Главное меню"""
    print("="*60)
    print("  ГЕНЕРАТОР ОПИСАНИЙ ДЛЯ ПОРТФОЛИО (Computer Vision)")
    print("="*60)
    
    manager = ModelManager()
    manager.show_available_models()
    
    print("Выберите режим:")
    print("1. 🧪 Тестовый режим (сравнить модели на 1 фото)")
    print("2. 🚀 Обработка партии (50 фото)")
    print("3. 🔥 Полная обработка (все фото)")
    print()
    
    mode = input("Ваш выбор [1-3]: ").strip()
    
    if mode == '1':
        # Тестовый режим
        print("\nНайдем тестовое изображение...")
        with open(CSV_FILE, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            for row in reader:
                local_path = row.get('file_path_local', '')
                full_path = os.path.join(ROOT, local_path)
                if os.path.exists(full_path):
                    test_models_on_sample(
                        full_path,
                        row.get('tax_category', ''),
                        row.get('post_title', '')
                    )
                    break
    
    elif mode in ['2', '3']:
        # Выбор модели
        print("\nВыберите модель:")
        print("1. Gemini Flash (API, быстро)")
        print("2. BLIP-2 (локально, медленно)")
        print("3. SmolVLM (локально, средне)")
        
        model_choice = input("Модель [1-3]: ").strip()
        
        method_map = {'1': 'gemini', '2': 'blip2', '3': 'smolvlm'}
        method = method_map.get(model_choice)
        
        if not method:
            print("❌ Неверный выбор")
            return
        
        api_key = None
        if method == 'gemini':
            api_key = input("Введите Gemini API ключ: ").strip()
            if not api_key:
                print("❌ API ключ обязателен для Gemini")
                return
        
        max_count = None if mode == '3' else 50
        process_images_batch(method, api_key, start_index=0, max_count=max_count)
    
    else:
        print("❌ Неверный выбор")


if __name__ == "__main__":
    main()
