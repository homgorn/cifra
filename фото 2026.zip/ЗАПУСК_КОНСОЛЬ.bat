@echo off
chcp 65001 >nul
title Генератор описаний - Консольный режим

REM Настройка пути для моделей (на диск E, не C)
set MODELS_PATH=e:\цифра 2026 хп\фото 2026\models_cache
set TRANSFORMERS_CACHE=%MODELS_PATH%\transformers
set HF_HOME=%MODELS_PATH%\huggingface
set TORCH_HOME=%MODELS_PATH%\torch

REM Создаем папку если нет
if not exist "%MODELS_PATH%" mkdir "%MODELS_PATH%"

echo ============================================
echo   ГЕНЕРАТОР ОПИСАНИЙ ФОТО (Консоль)
echo ============================================
echo 📁 Модели будут на: %MODELS_PATH%
echo ============================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python не найден!
    pause
    exit /b 1
)

echo Выберите действие:
echo.
echo 1. Установить зависимости
echo 2. Запустить интерактивный режим
echo 3. Тест на 1 фото (SmolVLM)
echo 4. Обработать 50 фото (SmolVLM)
echo 5. Установить Gemini библиотеку
echo 6. Установить локальные модели (BLIP-2, SmolVLM)
echo.

set /p choice="Ваш выбор [1-6]: "

if "%choice%"=="1" goto install_deps
if "%choice%"=="2" goto interactive
if "%choice%"=="3" goto test_one
if "%choice%"=="4" goto process_batch
if "%choice%"=="5" goto install_gemini
if "%choice%"=="6" goto install_local
goto end

:install_deps
echo.
echo ⏳ Установка базовых зависимостей...
pip install pillow
echo ✅ Готово!
pause
exit /b 0

:install_gemini
echo.
echo ⏳ Установка Gemini API...
pip install google-generativeai pillow
echo ✅ Готово!
echo.
echo 💡 Получите API ключ: https://makersuite.google.com/app/apikey
pause
exit /b 0

:install_local
echo.
echo ⏳ Установка библиотек для локальных моделей...
echo ⚠️  Это займет время и ~10GB места!
echo.
set /p confirm="Продолжить? [y/N]: "
if /i not "%confirm%"=="y" goto end

pip install transformers torch pillow
echo ✅ Готово!
pause
exit /b 0

:interactive
echo.
python generate_photo_descriptions.py
pause
exit /b 0

:test_one
echo.
echo 🧪 Тест на 1 фото с SmolVLM...
echo.
python -c "from generate_photo_descriptions import *; test_models_on_sample()"
pause
exit /b 0

:process_batch
echo.
echo 🚀 Обработка 50 фото с SmolVLM...
echo ⚠️  Это займет время!
echo.
set /p confirm="Продолжить? [y/N]: "
if /i not "%confirm%"=="y" goto end

python -c "from generate_photo_descriptions import *; process_images_batch('smolvlm', max_count=50)"
pause
exit /b 0

:end
echo.
echo Выход...
timeout /t 2 >nul
