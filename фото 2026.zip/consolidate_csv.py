import os
import csv

ROOT = r'e:\цифра 2026 хп\фото 2026'
OUTPUT_FILE = os.path.join(ROOT, 'master_portfolio_import.csv')

def consolidate():
    all_rows = []
    all_fieldnames = set()

    # Phase 1: Collect rows and all possible fieldnames
    for root, dirs, files in os.walk(ROOT):
        for f in files:
            if f.startswith('import_portfolio_') and f.endswith('.csv'):
                csv_path = os.path.join(root, f)
                print(f"Reading {csv_path}...")
                try:
                    with open(csv_path, 'r', encoding='utf-8-sig') as infile:
                        reader = csv.DictReader(infile)
                        if reader.fieldnames:
                            all_fieldnames.update(reader.fieldnames)
                        for row in reader:
                            all_rows.append(row)
                except Exception as e:
                    print(f"Error reading {csv_path}: {e}")

    if not all_rows:
        print("No rows found to consolidate.")
        return

    # Phase 2: Write consolidated file
    fieldnames_list = sorted(list(all_fieldnames))
    
    # Sort rows for better organization
    # Some older files might not have tax_category, handle that
    all_rows.sort(key=lambda x: (x.get('tax_category', ''), x.get('post_title', '')))

    with open(OUTPUT_FILE, 'w', encoding='utf-8-sig', newline='') as outfile:
        writer = csv.DictWriter(outfile, fieldnames=fieldnames_list)
        writer.writeheader()
        for row in all_rows:
            # Ensure all fieldnames exist in the row dict
            safe_row = {field: row.get(field, '') for field in fieldnames_list}
            writer.writerow(safe_row)

    print(f"\nSUCCESS! Consolidated {len(all_rows)} rows into {OUTPUT_FILE}")
    print(f"Fields: {', '.join(fieldnames_list)}")

if __name__ == "__main__":
    consolidate()
