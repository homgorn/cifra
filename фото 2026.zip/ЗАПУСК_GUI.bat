@echo off
chcp 65001 >nul
title Генератор описаний фото - GUI

REM Настройка пути для моделей (на диск E, не C)
set MODELS_PATH=e:\цифра 2026 хп\фото 2026\models_cache
set TRANSFORMERS_CACHE=%MODELS_PATH%\transformers
set HF_HOME=%MODELS_PATH%\huggingface
set TORCH_HOME=%MODELS_PATH%\torch

REM Создаем папку если нет
if not exist "%MODELS_PATH%" mkdir "%MODELS_PATH%"

echo ========================================
echo   ГЕНЕРАТОР ОПИСАНИЙ ФОТО (GUI)
echo ========================================
echo 📁 Модели будут загружаться на диск E:
echo    %MODELS_PATH%
echo ========================================
echo.

REM Проверка Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python не найден!
    echo Установите Python с https://python.org
    pause
    exit /b 1
)

echo ✅ Python найден
echo.

REM Проверка зависимостей
echo Проверка зависимостей...
pip show pillow >nul 2>&1
if errorlevel 1 (
    echo ⏳ Устанавливаем Pillow...
    pip install pillow
)

echo.
echo 🚀 Запуск GUI...
echo.

python photo_descriptions_gui.py

if errorlevel 1 (
    echo.
    echo ❌ Произошла ошибка!
    pause
    exit /b 1
)

pause
