import os
import csv
import shutil
import uuid
import re
from PIL import Image

# Global flag
HAS_AI_LIBS_LOADED = False

# --- CONFIGURATION ---
ROOT = r'e:\цифра 2026 хп\фото 2026'
DOMAIN = 'https://цифра18.рф'
UPLOAD_BASE = '/wp-content/uploads/portfolio/'
MODEL_ID = "openai/clip-vit-base-patch32"

# Transliteration mapping for SEO slugs
CYR_TO_LAT = {
    'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'yo', 'ж': 'zh',
    'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n', 'о': 'o',
    'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u', 'ф': 'f', 'х': 'h', 'ц': 'ts',
    'ч': 'ch', 'ш': 'sh', 'щ': 'shch', 'ъ': '', 'ы': 'y', 'ь': '', 'э': 'e', 'ю': 'yu', 'я': 'ya'
}

def slugify(text):
    text = text.lower().strip()
    result = ""
    for char in text:
        if char in CYR_TO_LAT:
            result += CYR_TO_LAT[char]
        elif char.isalnum():
            result += char
        else:
            result += '-'
    return re.sub(r'-+', '-', result).strip('-')

class UniversalOrganizer:
    def __init__(self, dry_run=True):
        self.dry_run = dry_run
        self.model = None
        self.processor = None
        # List actual folders for robust matching
        self.actual_folders = {d.lower(): d for d in os.listdir(ROOT) if os.path.isdir(os.path.join(ROOT, d))}
        print(f"Organizer initialized. Dry run: {dry_run}")
        print(f"Found {len(self.actual_folders)} directories in ROOT.")

    def load_ai(self):
        global HAS_AI_LIBS_LOADED
        if HAS_AI_LIBS_LOADED: return True
        print("Loading CLIP libraries (this may take 30s+)...")
        try:
            from transformers import CLIPProcessor, CLIPModel
            import torch
            self.model = CLIPModel.from_pretrained(MODEL_ID)
            self.processor = CLIPProcessor.from_pretrained(MODEL_ID)
            HAS_AI_LIBS_LOADED = True
            return True
        except Exception as e:
            print(f"Error loading AI: {e}")
            return False

    def process_folder(self, requested_folder, config=None):
        # Resolve actual folder name (case-insensitive and robust to encoding mismatch if passed from cli)
        folder_name = self.actual_folders.get(requested_folder.lower())
        if not folder_name:
            print(f"Folder NOT FOUND in ROOT: {requested_folder}")
            # Try partial matching as fallback
            for k in self.actual_folders.keys():
                if requested_folder.lower() in k:
                    folder_name = self.actual_folders[k]
                    print(f"Using fuzzy match: {folder_name}")
                    break
        
        if not folder_name:
            return

        path = os.path.join(ROOT, folder_name)
        print(f"\n--- Processing: {folder_name} ---")
        
        # Default config if none provided
        slug = slugify(folder_name)
        if not config:
            config = {
                'prefix': slug,
                'title': folder_name.title(),
                'cat': folder_name,
                'tags': folder_name.lower()
            }

        # 1. Collect images (avoid already organized folders)
        images = []
        for root, dirs, files in os.walk(path):
            # Prune directories starting with digits like "1_FOLDER"
            dirs[:] = [d for d in dirs if not (d[0].isdigit() and '_' in d)]
            for f in files:
                if f.lower().endswith(('.jpg', '.jpeg', '.png')) and not f.startswith('tmp_'):
                    images.append(os.path.join(root, f))

        if not images:
            print(f"No images found to process in {folder_name}.")
            return

        print(f"Found {len(images)} images.")

        plan = []
        # Complex classification if labels provided
        if config.get('labels') and self.load_ai():
            labels_list = [l['match'] for l in config['labels'].values()]
            labels_keys = list(config['labels'].keys())
            
            for img_path in images:
                try:
                    image = Image.open(img_path)
                    inputs = self.processor(text=labels_list, images=image, return_tensors="pt", padding=True)
                    with torch.no_grad():
                        outputs = self.model(**inputs)
                    probs = outputs.logits_per_image.softmax(dim=1)
                    conf, idx = probs[0].topk(1)
                    
                    label_key = labels_keys[idx.item()]
                    label_info = config['labels'][label_key]
                    
                    plan.append({
                        'old_path': img_path,
                        'cat_key': label_key,
                        'sub_info': label_info,
                        'conf': conf.item()
                    })
                except Exception as e:
                    print(f"Error classifying {img_path}: {e}")
        else:
            # Simple single category
            for img_path in images:
                plan.append({
                    'old_path': img_path,
                    'cat_key': 'default',
                    'sub_info': {
                        'folder': f"1_{folder_name.upper().replace(' ', '_')}",
                        'prefix': config['prefix'],
                        'title': config['title'],
                        'cat': config.get('cat', folder_name),
                        'tags': config.get('tags', folder_name)
                    },
                    'conf': 1.0
                })

        if self.dry_run:
            print(f"DRY RUN: Would organize {len(plan)} files.")
            for item in plan[:3]:
                print(f"  {os.path.basename(item['old_path'])} -> {item['sub_info']['folder']}/{item['sub_info']['prefix']}...")
            return

        # 2. Reorganize
        counters = {}
        csv_rows = []
        
        for item in plan:
            sub = item['sub_info']
            folder_path = os.path.join(path, sub['folder'])
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)
            
            count = counters.get(sub['folder'], 1)
            ext = os.path.splitext(item['old_path'])[1].lower()
            new_name = f"{sub['prefix']}-cifra18-rf-{count}{ext}"
            target_path = os.path.join(folder_path, new_name)
            
            # Move
            tmp_path = os.path.join(path, f"tmp_{uuid.uuid4().hex}{ext}")
            try:
                os.rename(item['old_path'], tmp_path)
                os.rename(tmp_path, target_path)
                counters[sub['folder']] = count + 1
            except Exception as e:
                print(f"Error moving {item['old_path']}: {e}")
                continue

            # CSV
            rel_path = f"{folder_name}/{sub['folder']}/{new_name}"
            image_url = f"{DOMAIN}{UPLOAD_BASE}{rel_path}"
            csv_rows.append({
                'post_title': f"{sub['title']} №{count}",
                'post_name': os.path.splitext(new_name)[0],
                'post_content': f"Пример работы: {sub['title']}. Нанесение логотипа методом печати или гравировки.",
                'tax_category': sub['cat'],
                'tax_post_tag': sub['tags'],
                'featured_image': image_url,
                'file_path_local': rel_path,
                'ai_confidence': f"{item['conf']:.1%}" if item['conf'] < 1.0 else ""
            })

        # 3. Save CSV
        if csv_rows:
            csv_file = os.path.join(path, f"import_portfolio_{slug}.csv")
            with open(csv_file, 'w', encoding='utf-8-sig', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=csv_rows[0].keys())
                writer.writeheader()
                writer.writerows(csv_rows)
            print(f"SUCCESS! {len(csv_rows)} files processed. CSV saved: {csv_file}")

if __name__ == "__main__":
    organizer = UniversalOrganizer(dry_run=False) # SET TO FALSE TO EXECUTE
    
    COMPLEX_CONFIGS = {
        'ПАПКИ УГОЛКИ ФАЙЛЫ': {
            'labels': {
                'papka_bum': {'match': 'cardboard document folder', 'folder': '1_PAPKI_BUMAZHNYE', 'prefix': 'papka-bumazhnaya', 'title': 'Бумажная папка', 'cat': 'Папки и файлы', 'tags': 'папка, бумажная папка'},
                'papka_ugol': {'match': 'plastic L-shaped corner folder', 'folder': '2_PAPKI_UGOLKI', 'prefix': 'papka-ugolok', 'title': 'Папка-уголок', 'cat': 'Папки и файлы', 'tags': 'папка-уголок, пластиковая папка'},
                'fail_vkladysh': {'match': 'punched pocket file', 'folder': '3_FAILY_VKLADYSHI', 'prefix': 'fail-vkladysh', 'title': 'Файл-вкладыш', 'cat': 'Папки и файлы', 'tags': 'файл-вкладыш, файл для документов'},
                'papka_kolca': {'match': 'ring binder', 'folder': '4_PAPKI_S_KOLCAMI', 'prefix': 'papka-na-kolcah', 'title': 'Папка на кольцах', 'cat': 'Папки и файлы', 'tags': 'папка на кольцах, логотип'}
            }
        },
        'РУЧКИ, БЛОКНОТЫ': {
            'labels': {
                'ruchky': {'match': 'ballpoint pen', 'folder': '1_RUCHKI', 'prefix': 'ruchka-s-logotipom', 'title': 'Ручка с логотипом', 'cat': 'Ручки и блокноты', 'tags': 'ручка, печать на ручках'},
                'bloknoty': {'match': 'paper notebook', 'folder': '2_BLOKNOTY', 'prefix': 'bloknot-s-logotipom', 'title': 'Блокнот с логотипом', 'cat': 'Ручки и блокноты', 'tags': 'блокнот, ежедневник'},
                'futlyary': {'match': 'pen case gift box', 'folder': '3_FUTLYARY', 'prefix': 'futlyar-dlya-ruchki', 'title': 'Футляр для ручки', 'cat': 'Ручки и блокноты', 'tags': 'футляр, упаковка'}
            }
        },
        'ОДЕЖДА': {
            'labels': {
                'futbolka': {'match': 't-shirt with print', 'folder': '1_FUTBOLKI', 'prefix': 'futbolka-s-pechatyu', 'title': 'Футболка с печатью', 'cat': 'Одежда', 'tags': 'футболка, печать на одежде'},
                'hudi': {'match': 'hoodie or sweatshirt', 'folder': '2_HUDI_S_LOGOTIPOM', 'prefix': 'hudi-tolstovka-s-logotipom', 'title': 'Худи или толстовка', 'cat': 'Одежда', 'tags': 'худи, толстовка, вышивка'},
                'kepka': {'match': 'baseball cap or hat', 'folder': '3_KEPKI', 'prefix': 'kepka-beysbolka-s-logotipom', 'title': 'Кепка-бейсболка', 'cat': 'Одежда', 'tags': 'кепка, бейсболка, логотип'}
            }
        },
        'ШОКОЛАД': {
            'labels': {
                'shokolad_standart': {'match': 'chocolate bar in a wrapper', 'folder': '1_SHOKOLAD_5G', 'prefix': 'shokolad-s-logotipom', 'title': 'Шоколад с логотипом', 'cat': 'Шоколад', 'tags': 'шоколад, сувенир'},
                'shokolad_nabor': {'match': 'gift set of chocolates in a box', 'folder': '2_SHOKOLADNIE_NABORY', 'prefix': 'shokoladniy-nabor', 'title': 'Шоколадный набор', 'cat': 'Шоколад', 'tags': 'набор шоколада, подарок'}
            }
        }
    }
    
    # Process Wave 1 (Simple)
    wave1_targets = {
        'бирки', 'визитки', 'бейдж', 'грамоты', 'магниты', 
        'браслеты', 'билеты', 'закладки магнитные', 'зонт', 
        'кубарики', 'меню', 'переплет', 'плакетки', 'попсокеты', 
        'тейбл-тенты', 'трек', 'флаг', 'часы', 'чехол'
    }
    
    # Process Wave 2 (Complex)
    wave2_targets = set(k.lower() for k in COMPLEX_CONFIGS.keys())
    
    # Match actual folders in ROOT against targets
    actual_dirs = [d for d in os.listdir(ROOT) if os.path.isdir(os.path.join(ROOT, d))]
    for d in actual_dirs:
        d_lower = d.lower()
        if d_lower in wave1_targets:
            organizer.process_folder(d)
        elif d_lower in wave2_targets:
            # Find original key for config
            orig_key = [k for k in COMPLEX_CONFIGS.keys() if k.lower() == d_lower][0]
            organizer.process_folder(d, config=COMPLEX_CONFIGS[orig_key])
