@echo off
chcp 65001 >nul
title Очистка кэша моделей с диска C

echo ============================================
echo   ОЧИСТКА КЭША МОДЕЛЕЙ С ДИСКА C
echo ============================================
echo.
echo ⚠️  Этот скрипт удалит кэш моделей Hugging Face
echo    и PyTorch с диска C, чтобы освободить место.
echo.
echo Будут удалены папки:
echo   C:\Users\%USERNAME%\.cache\huggingface\
echo   C:\Users\%USERNAME%\.cache\torch\
echo.

set CACHE_HF=C:\Users\%USERNAME%\.cache\huggingface
set CACHE_TORCH=C:\Users\%USERNAME%\.cache\torch

REM Проверяем размер кэша
echo Проверяем текущий размер кэша...
echo.

if exist "%CACHE_HF%" (
    echo 📁 HuggingFace кэш найден:
    dir "%CACHE_HF%" | find "File(s)"
) else (
    echo ✅ HuggingFace кэш не найден (хорошо!)
)

if exist "%CACHE_TORCH%" (
    echo 📁 PyTorch кэш найден:
    dir "%CACHE_TORCH%" | find "File(s)"
) else (
    echo ✅ PyTorch кэш не найден (хорошо!)
)

echo.
echo ============================================
echo.

if not exist "%CACHE_HF%" if not exist "%CACHE_TORCH%" (
    echo ✅ Кэш на диске C не найден. Очистка не требуется!
    pause
    exit /b 0
)

set /p confirm="❗ Удалить весь кэш с диска C? [y/N]: "

if /i not "%confirm%"=="y" (
    echo.
    echo Отменено пользователем.
    pause
    exit /b 0
)

echo.
echo Удаляем кэш...

if exist "%CACHE_HF%" (
    echo Удаляем HuggingFace кэш...
    rmdir /s /q "%CACHE_HF%" 2>nul
    if exist "%CACHE_HF%" (
        echo ⚠️  Не удалось удалить полностью (возможно файлы используются)
    ) else (
        echo ✅ HuggingFace кэш удален
    )
)

if exist "%CACHE_TORCH%" (
    echo Удаляем PyTorch кэш...
    rmdir /s /q "%CACHE_TORCH%" 2>nul
    if exist "%CACHE_TORCH%" (
        echo ⚠️  Не удалось удалить полностью (возможно файлы используются)
    ) else (
        echo ✅ PyTorch кэш удален
    )
)

echo.
echo ============================================
echo ✅ Очистка завершена!
echo.
echo 💡 Теперь все модели будут скачиваться на диск E:
echo    e:\цифра 2026 хп\фото 2026\models_cache\
echo ============================================
echo.

pause
