import os
import csv
import shutil
import uuid
import re
from PIL import Image

ROOT = r'e:\цифра 2026 хп\фото 2026'
DOMAIN = 'https://цифра18.рф'
UPLOAD_BASE = '/wp-content/uploads/portfolio/'

CYR_TO_LAT = {
    'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'yo', 'ж': 'zh',
    'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n', 'о': 'o',
    'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u', 'ф': 'f', 'х': 'h', 'ц': 'ts',
    'ч': 'ch', 'ш': 'sh', 'щ': 'shch', 'ъ': '', 'ы': 'y', 'ь': '', 'э': 'e', 'ю': 'yu', 'я': 'ya'
}

def slugify(text):
    text = text.lower().strip()
    result = ""
    for char in text:
        if char in CYR_TO_LAT:
            result += CYR_TO_LAT[char]
        elif char.isalnum():
            result += char
        else:
            result += '-'
    return re.sub(r'-+', '-', result).strip('-')

def process_folder(folder_name):
    path = os.path.join(ROOT, folder_name)
    if not os.path.exists(path):
        print(f"Path does not exist: {path}")
        return

    print(f"\n--- Processing: {folder_name} ---")
    slug = slugify(folder_name)
    
    # Collect images recursively (skip organized folders and scripts)
    images = []
    for root, dirs, files in os.walk(path):
        # Prune organized folders to skip them
        dirs[:] = [d for d in dirs if not (d.startswith('1_') or d.startswith('2_') or d.startswith('3_') or d.startswith('4_'))]
        for f in files:
            if f.lower().endswith(('.jpg', '.jpeg', '.png')) and not f.startswith('tmp_'):
                images.append(os.path.join(root, f))

    if not images:
        print(f"No unprocessed images found in {folder_name}.")
        return

    print(f"Found {len(images)} images.")
    
    # Create organized subfolder
    org_folder = f"1_{folder_name.upper().replace(' ', '_').replace(',', '')}"
    org_path = os.path.join(path, org_folder)
    if not os.path.exists(org_path):
        os.makedirs(org_path)

    csv_rows = []
    count = 1
    
    for img_path in images:
        ext = os.path.splitext(img_path)[1].lower()
        new_name = f"{slug}-cifra18-rf-{count}{ext}"
        target_path = os.path.join(org_path, new_name)
        
        # Move via temp
        tmp_name = f"tmp_{uuid.uuid4().hex}{ext}"
        tmp_path = os.path.join(ROOT, tmp_name) # Move to root temp to avoid nested issues
        try:
            shutil.move(img_path, tmp_path)
            shutil.move(tmp_path, target_path)
        except Exception as e:
            print(f"Error moving {img_path}: {e}")
            continue

        # CSV row
        rel_path = f"{folder_name}/{org_folder}/{new_name}"
        image_url = f"{DOMAIN}{UPLOAD_BASE}{rel_path}"
        csv_rows.append({
            'post_title': f"{folder_name.title()} №{count}",
            'post_name': os.path.splitext(new_name)[0],
            'post_content': f"Пример работы: {folder_name.title()}. Нанесение логотипа.",
            'tax_category': folder_name,
            'tax_post_tag': folder_name.lower(),
            'featured_image': image_url,
            'file_path_local': rel_path
        })
        count += 1

    # Save CSV
    if csv_rows:
        csv_file = os.path.join(path, f"import_portfolio_{slug}.csv")
        # Check if CSV exists, if so, append or overwrite? User wants "continue", so overwrite is fine for new runs.
        with open(csv_file, 'w', encoding='utf-8-sig', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=csv_rows[0].keys())
            writer.writeheader()
            writer.writerows(csv_rows)
        print(f"SUCCESS! {len(csv_rows)} files processed. CSV: {csv_file}")

if __name__ == "__main__":
    # Get all folders in ROOT
    all_dirs = [d for d in os.listdir(ROOT) if os.path.isdir(os.path.join(ROOT, d)) and not d.startswith('.')]
    
    # Skip already fully processed folders if they have no new images
    for d in all_dirs:
        process_folder(d)
