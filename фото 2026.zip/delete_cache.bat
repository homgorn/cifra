@echo off
echo Deleting HuggingFace cache from C drive...
echo.

set CACHE_PATH=C:\Users\thefr\.cache\huggingface

if exist "%CACHE_PATH%" (
    echo Found cache at: %CACHE_PATH%
    echo Deleting...
    rmdir /s /q "%CACHE_PATH%"
    
    if exist "%CACHE_PATH%" (
        echo WARNING: Could not delete completely
    ) else (
        echo SUCCESS: Cache deleted!
    )
) else (
    echo Cache not found (already clean)
)

echo.
pause
