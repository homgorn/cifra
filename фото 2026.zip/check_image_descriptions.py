import os
import csv

ROOT = r'e:\цифра 2026 хп\фото 2026'
CSV_FILE = os.path.join(ROOT, 'master_portfolio_import.csv')

def analyze_descriptions():
    """Анализируем, сколько фото имеют реальные описания"""
    
    if not os.path.exists(CSV_FILE):
        print(f"CSV файл не найден: {CSV_FILE}")
        return
    
    with open(CSV_FILE, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    print(f"=== АНАЛИЗ ОПИСАНИЙ ФОТО ===\n")
    print(f"Всего записей в CSV: {len(rows)}")
    
    # Анализируем описания
    generic_descriptions = 0
    has_ai_confidence = 0
    unique_categories = set()
    
    for row in rows:
        unique_categories.add(row.get('tax_category', ''))
        
        # Проверяем, является ли описание шаблонным
        content = row.get('post_content', '')
        if 'Пример работы:' in content and 'Нанесение логотипа' in content:
            generic_descriptions += 1
        
        # Проверяем наличие AI анализа
        if row.get('ai_confidence', '').strip():
            has_ai_confidence += 1
    
    print(f"Уникальных категорий: {len(unique_categories)}")
    print(f"Записей с шаблонным описанием: {generic_descriptions} ({generic_descriptions/len(rows)*100:.1f}%)")
    print(f"Записей с AI confidence: {has_ai_confidence} ({has_ai_confidence/len(rows)*100:.1f}%)")
    print(f"\nВЫВОД: Нужно создать описания для ~{generic_descriptions} фото")
    
    # Проверяем существование файлов
    print("\n=== ПРОВЕРКА ФАЙЛОВ ===")
    existing_files = 0
    missing_files = 0
    
    for i, row in enumerate(rows[:10]):  # Проверяем первые 10
        local_path = row.get('file_path_local', '')
        full_path = os.path.join(ROOT, local_path)
        if os.path.exists(full_path):
            existing_files += 1
        else:
            missing_files += 1
            print(f"Не найден: {local_path}")
    
    print(f"\nИз первых 10 файлов: существует {existing_files}, не найдено {missing_files}")

if __name__ == "__main__":
    analyze_descriptions()
